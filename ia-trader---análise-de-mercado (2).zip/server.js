import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Platform requirement: dev server must always listen on port 3000
const PORT = 3000;

// Helper to get Gemini API key
function getGeminiApiKey() {
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim() !== '') {
    return process.env.GEMINI_API_KEY.trim();
  }
  try {
    const devEnvPath = '/app/.dev.env.json';
    if (fs.existsSync(devEnvPath)) {
      const parsed = JSON.parse(fs.readFileSync(devEnvPath, 'utf8'));
      if (parsed.GEMINI_API_KEY) return parsed.GEMINI_API_KEY.trim();
    }
  } catch (e) {
    console.error('Error reading .dev.env.json:', e);
  }
  return '';
}

// Generate realistic chart SVG samples as base64 for 1-click testing with ICT concepts
function createSampleChartSvg(type) {
  let title = '';
  let subtitle = '';
  let candles = [];
  let extraAnnotations = '';

  if (type === 'alta') {
    title = 'NQ (Nasdaq) 15m • Setup Bullish CISD de Reversão + BISI';
    subtitle = 'ICT: SSL Sweep em Q2 Judas → CISD de Reversão com Displacement para BSL';
    candles = [
      { x: 45, o: 195, c: 215, h: 225, l: 190, up: false },
      { x: 80, o: 215, c: 235, h: 240, l: 205, up: false },
      { x: 115, o: 235, c: 255, h: 260, l: 230, up: false },
      // Candle 4: Sweep of Sell-Side Liquidity (SSL) with long wick
      { x: 150, o: 255, c: 250, h: 265, l: 295, up: true }, 
      // Candle 5: Order Block / Initiation
      { x: 185, o: 250, c: 215, h: 255, l: 210, up: true },
      // Candle 6: Aggressive displacement creating Bullish FVG (BISI) and breaking market structure
      { x: 220, o: 215, c: 165, h: 220, l: 160, up: true },
      // Candle 7: Tap into FVG (Discount)
      { x: 255, o: 165, c: 185, h: 160, l: 195, up: false },
      // Candle 8 & 9: Expansion toward BSL
      { x: 290, o: 185, c: 140, h: 190, l: 135, up: true },
      { x: 325, o: 140, c: 110, h: 145, l: 105, up: true },
    ];
    extraAnnotations = `
      <!-- SSL Sweep Line -->
      <line x1="30" y1="285" x2="370" y2="285" stroke="#EF4444" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="280" fill="#EF4444" font-size="9" font-family="monospace" font-weight="bold">SSL (Sell-Side Liquidity Swept)</text>

      <!-- Bullish FVG (BISI) Zone -->
      <rect x="215" y="195" width="80" height="25" fill="#10B981" fill-opacity="0.18" stroke="#10B981" stroke-width="1" stroke-dasharray="2" rx="3" />
      <text x="220" y="211" fill="#34D399" font-size="9" font-family="monospace" font-weight="bold">Bullish FVG (BISI)</text>

      <!-- CISD de Reversão Marker -->
      <line x1="180" y1="215" x2="340" y2="215" stroke="#38BDF8" stroke-width="1.5" stroke-dasharray="4" />
      <text x="185" y="210" fill="#38BDF8" font-size="9" font-family="monospace" font-weight="bold">CISD de Reversão (Change In State of Delivery)</text>

      <!-- BSL Target Line -->
      <line x1="30" y1="95" x2="370" y2="95" stroke="#10B981" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="90" fill="#10B981" font-size="9" font-family="monospace" font-weight="bold">BSL Alvo (Buy-Side Liquidity)</text>
    `;
  } else if (type === 'baixa') {
    title = 'ES (S&P 500) 5m • Setup Bearish CISD de Reversão + SIBI';
    subtitle = 'ICT: BSL Sweep em Q2 Judas → CISD de Reversão Baixista com Displacement';
    candles = [
      { x: 45, o: 230, c: 205, h: 235, l: 200, up: true },
      { x: 80, o: 205, c: 175, h: 210, l: 170, up: true },
      { x: 115, o: 175, c: 145, h: 180, l: 140, up: true },
      // Candle 4: Sweep of Buy-Side Liquidity (BSL) with long high wick
      { x: 150, o: 145, c: 150, h: 105, l: 155, up: false },
      // Candle 5: Bearish displacement
      { x: 185, o: 150, c: 190, h: 145, l: 195, up: false },
      // Candle 6: Aggressive displacement creating Bearish FVG (SIBI)
      { x: 220, o: 190, c: 245, h: 185, l: 250, up: false },
      // Candle 7: Retest into Bearish FVG (Premium)
      { x: 255, o: 245, c: 220, h: 215, l: 250, up: true },
      // Candle 8 & 9: Expansion toward SSL
      { x: 290, o: 220, c: 265, h: 215, l: 270, up: false },
      { x: 325, o: 265, c: 295, h: 260, l: 300, up: false },
    ];
    extraAnnotations = `
      <!-- BSL Sweep Line -->
      <line x1="30" y1="115" x2="370" y2="115" stroke="#10B981" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="110" fill="#10B981" font-size="9" font-family="monospace" font-weight="bold">BSL (Buy-Side Liquidity Swept)</text>

      <!-- Bearish FVG (SIBI) Zone -->
      <rect x="215" y="195" width="80" height="25" fill="#EF4444" fill-opacity="0.18" stroke="#EF4444" stroke-width="1" stroke-dasharray="2" rx="3" />
      <text x="220" y="211" fill="#F87171" font-size="9" font-family="monospace" font-weight="bold">Bearish FVG (SIBI)</text>

      <!-- Bearish CISD de Reversão Marker -->
      <line x1="180" y1="190" x2="340" y2="190" stroke="#F59E0B" stroke-width="1.5" stroke-dasharray="4" />
      <text x="185" y="185" fill="#F59E0B" font-size="9" font-family="monospace" font-weight="bold">CISD de Reversão Baixista</text>

      <!-- SSL Target Line -->
      <line x1="30" y1="290" x2="370" y2="290" stroke="#EF4444" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="285" fill="#EF4444" font-size="9" font-family="monospace" font-weight="bold">SSL Alvo (Sell-Side Liquidity)</text>
    `;
  } else {
    title = 'EUR/USD 1H • Asian Range / Acumulação Q1';
    subtitle = 'ICT: Sem CISD de Reversão ou Continuação • Liquidez intacta • Aguardar Q2';
    candles = [
      { x: 45, o: 175, c: 190, h: 205, l: 165, up: false },
      { x: 80, o: 190, c: 165, h: 195, l: 160, up: true },
      { x: 115, o: 165, c: 195, h: 205, l: 160, up: false },
      { x: 150, o: 195, c: 170, h: 205, l: 165, up: true },
      { x: 185, o: 170, c: 190, h: 200, l: 165, up: false },
      { x: 220, o: 190, c: 170, h: 200, l: 160, up: true },
      { x: 255, o: 170, c: 185, h: 195, l: 165, up: false },
      { x: 290, o: 185, c: 175, h: 195, l: 170, up: true },
      { x: 325, o: 175, c: 180, h: 190, l: 170, up: false },
    ];
    extraAnnotations = `
      <!-- Asian High BSL -->
      <line x1="30" y1="155" x2="370" y2="155" stroke="#38BDF8" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="150" fill="#38BDF8" font-size="9" font-family="monospace" font-weight="bold">Asian High (BSL Pool)</text>

      <!-- Asian Low SSL -->
      <line x1="30" y1="215" x2="370" y2="215" stroke="#38BDF8" stroke-width="1.5" stroke-dasharray="3" />
      <text x="35" y="210" fill="#38BDF8" font-size="9" font-family="monospace" font-weight="bold">Asian Low (SSL Pool)</text>

      <!-- Equilibrium -->
      <line x1="30" y1="185" x2="370" y2="185" stroke="#64748B" stroke-width="1" stroke-dasharray="2" />
      <text x="320" y="180" fill="#64748B" font-size="8" font-family="monospace">50% EQ</text>
    `;
  }

  const svgCandles = candles.map(c => {
    const col = c.up ? '#10B981' : '#EF4444';
    const top = Math.min(c.o, c.c);
    const h = Math.max(Math.abs(c.c - c.o), 4);
    return `
      <line x1="${c.x + 10}" y1="${c.h}" x2="${c.x + 10}" y2="${c.l}" stroke="${col}" stroke-width="2" />
      <rect x="${c.x}" y="${top}" width="20" height="${h}" fill="${col}" rx="2" />
    `;
  }).join('');

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="400" height="320" viewBox="0 0 400 320" style="background:#090D16;font-family:sans-serif;">
      <!-- Grid -->
      <line x1="20" y1="75" x2="380" y2="75" stroke="#1E293B" stroke-dasharray="3" opacity="0.4" />
      <line x1="20" y1="135" x2="380" y2="135" stroke="#1E293B" stroke-dasharray="3" opacity="0.4" />
      <line x1="20" y1="195" x2="380" y2="195" stroke="#1E293B" stroke-dasharray="3" opacity="0.4" />
      <line x1="20" y1="255" x2="380" y2="255" stroke="#1E293B" stroke-dasharray="3" opacity="0.4" />
      
      <!-- Title & ICT Subtitle -->
      <text x="18" y="26" fill="#F8FAFC" font-size="12" font-weight="bold" letter-spacing="0.2">${title}</text>
      <text x="18" y="44" fill="#38BDF8" font-size="9.5" font-family="monospace">${subtitle}</text>
      
      <!-- Annotations (FVG, Liquidity, CISD) -->
      ${extraAnnotations}

      <!-- Candles -->
      ${svgCandles}
      
      <!-- ICT watermark -->
      <text x="18" y="308" fill="#475569" font-size="9" font-family="monospace">ICT Smart Money Concepts Engine • IPDA Algorithm</text>
    </svg>
  `.trim();

  return 'data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64');
}

// Multimodal models in order of priority (flash-lite provides fast response and high availability)
const VISION_MODELS = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];

// Call Gemini Vision model with pure ICT & SMC concepts
async function analyzeChartWithGemini(imageBase64, mimeType = 'image/png', assetContext = '', timeframeHint = '') {
  const apiKey = getGeminiApiKey();

  if (!apiKey) {
    throw new Error('Chave GEMINI_API_KEY não foi encontrada no ambiente. Por favor, configure sua chave do Gemini.');
  }

  // Normalize base64 and extract mime
  let pureBase64 = imageBase64;
  let cleanMime = mimeType || 'image/png';

  if (imageBase64.includes(';base64,')) {
    const parts = imageBase64.split(';base64,');
    pureBase64 = parts[1];
    if (parts[0].startsWith('data:')) {
      cleanMime = parts[0].replace('data:', '').trim();
    }
  } else if (imageBase64.includes(',')) {
    pureBase64 = imageBase64.split(',')[1];
  }

  // Standardize mime types
  if (cleanMime === 'image/jpg') cleanMime = 'image/jpeg';
  if (!cleanMime || cleanMime === 'text/plain') cleanMime = 'image/png';

  const prompt = `
Você é uma Inteligência Artificial especialista de elite em metodologia ICT (Inner Circle Trader) e Smart Money Concepts (SMC), com domínio profundo da Entrega Algorítmica de Preço (IPDA).
VOCÊ ESTÁ ESTRITAMENTE PROIBIDO DE USAR OU CITAR INDICADORES TÉCNICOS TRADICIONAIS DE VAREJO (NÃO utilize RSI, IFR, Médias Móveis, MACD, Estocástico, Bandas de Bollinger, suportes/resistências convencionais de varejo).

Sua análise deve se concentrar EXCLUSIVAMENTE nos seguintes conceitos e pilares institucionais do ICT:

1. ESTRUTURA DE MERCADO (CISD de Reversão e CISD de Continuação):
   - Avalie a estrutura de entrega algorítmica identificando se houve:
     * CISD de Reversão (Change In State of Delivery - Reversão): Quebra da perna de entrega anterior com forte displacement (deslocamento agressivo com corpo cheio) fechando além de um Swing High (topo) ou Swing Low (fundo) chave após captura/sweep de liquidez, assinalando reversão institucional do order flow.
     * CISD de Continuação (Change In State of Delivery - Continuação): Rompimento e deslocamento agressivo de continuidade a favor da tendência institucional vigente, confirmando a sequência da entrega algorítmica de preço.
     * Sem Quebra Estrutural / Sem CISD (Consolidação/Range): Mercado contido dentro de Dealing Range sem rompimento de pivôs chave nem displacement.
   - Identifique o nível ou pivô rompido, o candle de displacement e se a estrutura está Confirmada, Em Formação ou Ausente.

2. FAIR VALUE GAPS (FVG - Ineficiências de Preço):
   - Mapeie ineficiências de liquidez formadas por 3 candles sem sobreposição de pavios:
     * Bullish FVG (BISI - Buyside Imbalance, Sellside Inefficiency): Aberto para reteste em zona de desconto para continuação compradora.
     * Bearish FVG (SIBI - Sellside Imbalance, Buyside Inefficiency): Aberto para reteste em zona de prêmio para continuação vendedora.
     * Inverse FVG (IFVG): FVG rompido que se inverte como suporte ou resistência.
   - Forneça a faixa de preço exata e o nível de 50% Consequent Encroachment (CE).
   - Indique o status de mitigação: Aberto para teste, Parcialmente Mitigado, Mitigado ou Respeitado.

3. NÍVEIS DE LIQUIDEZ (Buy/Sell Side Pools & Sweeps):
   - Buy-Side Liquidity (BSL): Mapeie topos iguais (EQH - Equal Highs), máximas de sessões anteriores (PDH, Asian High, London High) e topos estruturais onde repousam stops de compra e liquidez de breakout.
   - Sell-Side Liquidity (SSL): Mapeie fundos iguais (EQL - Equal Lows), mínimas de sessões anteriores (PDL, Asian Low) e fundos estruturais onde repousam stops de venda.
   - Sweeps / Liquidity Runs: Identifique se ocorreu varredura agressiva (sweep com rejeição por pavio) capturando ordens de varejo antes da reversão institucional.
   - Defina o Alvo Principal de liquidez (BSL, SSL ou Equilíbrio).

4. QUARTERLY THEORY (AMTD - Teoria dos Quatros):
   - Descreva minuciosamente o cenário atual com base no ciclo de 90 minutos ou nas sessões institucionais (Ciclo AMTD):
     * Q1: Acumulação (Consolidação inicial de volume e formação do range de referência).
     * Q2: Manipulação / Judas Swing (Falsa expansão que induz o varejo e captura liquidez BSL/SSL nas extremidades).
     * Q3: Distribuição / Expansão Direcional (O movimento institucional autêntico e de maior amplitude da sessão).
     * Q4: Exaustão / Reversão ou Consolidação Final (Realização de lucros institucionais e desaceleração do fluxo).
   - Forneça a descrição rica e contextualizada do timing do preço no ciclo.

5. SINCRONIZAÇÃO DE ATIVOS (Asset Synchronization & SMT Divergence):
   - Avalie a sincronização entre a cesta de ativos correlacionados no mesmo mercado:
     * Índices Futuros: NQ (Nasdaq) vs ES (S&P 500) vs YM (Dow Jones).
     * Câmbio/Forex: EUR/USD vs GBP/USD vs DXY (Dollar Index).
     * Criptoativos: BTC vs ETH.
     * Mercado Brasileiro (B3): WIN (Mini Índice) vs WDO (Mini Dólar).
   - Identifique ou projete Divergência SMT (Smart Money Tool): Ocorre quando um ativo renova máxima/mínima enquanto o ativo correlacionado falha em renovar, revelando a verdadeira intenção algorítmica.

6. PD ARRAY & DEALING RANGE:
   - Determine se o preço negocia em DISCOUNT (< 50% do Dealing Range - favorável para compras) ou PREMIUM (> 50% do Dealing Range - favorável para vendas).
   - Identifique o Order Block (Bullish OB / Bearish OB) institucional relevante.

7. PONTOS OPERACIONAIS ICT:
   - Entrada: Refinada no reteste do FVG (BISI/SIBI), no Consequent Encroachment (50% CE) ou no Order Block institucional.
   - Stop Loss: Invalidação técnica posicionado logo além da mínima/máxima do sweep ou da base da estrutura.
   - Take Profit 1: Primeira piscina de liquidez interna (Internal Range Liquidity - IRL).
   - Take Profit 2: Piscina de liquidez externa alvo (External Range Liquidity - ERL: BSL ou SSL).
   - Relação Risco/Retorno (R:R).

8. CRITÉRIOS PARA O SINAL INSTITUCIONAL:
   - "COMPRA": Liquidez SSL varrida (sweep) + CISD de reversão ou de continuação de alta com displacement + Bullish FVG (BISI) em zona de Discount.
   - "VENDA": Liquidez BSL varrida (sweep) + CISD de reversão ou de continuação de baixa com displacement + Bearish FVG (SIBI) em zona de Premium.
   - "NEUTRO": Preço em range Q1 (Acumulação), operando no Equilibrium sem sweep de liquidez e sem CISD confirmado.

Retorne ESTRITAMENTE um objeto JSON válido (sem caracteres markdown de formatação antes ou depois) com o seguinte esquema exato:
{
  "sinal": "COMPRA" | "VENDA" | "NEUTRO",
  "confianca": 88,
  "ativo": "Nome do ativo identificado no gráfico",
  "tempoGrafico": "ex: 5m, 15m, 1h, 1D",
  "biasInstitucional": "Bullish (Alta)" | "Bearish (Baixa)" | "Neutro / Consolidação",
  "estruturaMercado": {
    "tipo": "CISD de Reversão" | "CISD de Continuação" | "Sem Quebra Estrutural (Range)",
    "status": "Confirmado com Displacement" | "Em Formação" | "Não Detectado",
    "direcao": "Bullish" | "Bearish" | "Neutro",
    "pivoOuNivelRompido": "ex: Nível chave rompido com displacement",
    "displacement": "Deslocamento agressivo fechando além do último ponto de entrega",
    "detalhes": "Descrição técnica aprofundada da estrutura (CISD de reversão ou continuação) e validação da mudança ou continuidade no estado de entrega institucional"
  },
  "fairValueGaps": {
    "presente": true,
    "tipo": "Bullish FVG (BISI)" | "Bearish FVG (SIBI)" | "Inverse FVG (IFVG)" | "Nenhum",
    "faixaPreco": "ex: 18.120 - 18.150",
    "consequentEncroachment": "ex: 18.135 (50% CE)",
    "statusMitigacao": "Aberto para teste em Discount" | "Parcialmente Mitigado" | "Mitigado",
    "detalhes": "Mapeamento da ineficiência de 3 candles sem sobreposição de pavios e nível de equilíbrio"
  },
  "niveisLiquidez": {
    "buySideLiquidity_BSL": "ex: Topos iguais (EQH) em 18.350 / PDH",
    "sellSideLiquidity_SSL": "ex: Mínima da sessão asiática em 18.080 / EQL",
    "sweepDetectado": "Sweep de SSL executado" | "Sweep de BSL executado" | "Sem sweep recente",
    "alvoPrincipal": "BSL (Buy-Side Liquidity)" | "SSL (Sell-Side Liquidity)" | "Equilíbrio",
    "detalhesSweep": "Identificação detalhada de onde os stops foram caçados e o alvo de liquidez primário",
    "piscinasMapeadas": [
      "BSL: Topos iguais (EQH) em 18.350",
      "SSL: Mínima da sessão anterior em 18.080"
    ]
  },
  "quarterlyTheory": {
    "faseAtual": "Q1 (Acumulação)" | "Q2 (Manipulação / Judas Swing)" | "Q3 (Distribuição / Expansão)" | "Q4 (Exaustão / Reversão)",
    "cicloTempo": "ex: Ciclo de 90min / Sessão de NY AM",
    "descricaoCenario": "Descrição minuciosa do cenário atual de mercado sob a ótica da Teoria dos Quatros (AMTD)"
  },
  "sincronizacaoAtivos": {
    "ativosCorrelacionados": "ex: NQ vs ES ou EUR/USD vs DXY ou WIN vs WDO",
    "statusSMT": "Divergência SMT Confirmada" | "Fluxo Sincronizado" | "Sem Divergência",
    "divergenciaDetectada": true,
    "descricaoSincronizacao": "Análise da sincronização de fluxo e detecção de quebra de simetria SMT entre os ativos correlacionados"
  },
  "pdArray": {
    "zona": "Discount (< 50% Dealing Range)" | "Premium (> 50% Dealing Range)" | "Equilibrium (50%)",
    "orderBlock": "Bullish OB / Bearish OB mapeado no gráfico"
  },
  "pontosOperacionais": {
    "entrada": "Valor refinado de entrada no FVG ou OB",
    "stopLoss": "Nível de invalidação técnica posicionado além do sweep ou OB",
    "takeProfit1": "Alvo 1 (Internal Range Liquidity - IRL)",
    "takeProfit2": "Alvo 2 (External Range Liquidity - ERL / BSL / SSL)",
    "riscoRetorno": "ex: 1 : 3.2"
  },
  "confluenciasIct": [
    "Confluência ICT 1",
    "Confluência ICT 2",
    "Confluência ICT 3"
  ],
  "justificativaIct": "Síntese institucional técnica unindo Estrutura de Entrega (CISD de Reversão / Continuação), FVG, Níveis de Liquidez Buy/Sell Side, Cenário conforme Quarterly Theory e Sincronização de Ativos.",
  "avisoRisco": "Análise baseada exclusivamente na metodologia ICT/SMC para estudo de entrega algorítmica de preço. Não constitui recomendação de investimento."
}
`.trim();

  let lastError = null;

  // Try active models in order of priority
  for (const model of VISION_MODELS) {
    try {
      console.log(`[IA Trader Vision ICT] Consultando modelo ${model}...`);
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
                {
                  inlineData: {
                    mimeType: cleanMime,
                    data: pureBase64
                  }
                }
              ]
            }
          ],
          generationConfig: {
            responseMimeType: 'application/json',
            temperature: 0.15
          }
        })
      });

      if (response.status === 503 || response.status === 429) {
        const errText = await response.text();
        console.warn(`[IA Trader Vision ICT] Modelo ${model} sobrecarregado (HTTP ${response.status}): ${errText.slice(0, 100)}. Tentando próximo modelo...`);
        lastError = new Error(`Modelo ${model} ocupado no momento`);
        continue;
      }

      if (!response.ok) {
        const errText = await response.text();
        console.error(`[IA Trader Vision ICT] Erro na API com ${model} (HTTP ${response.status}):`, errText);
        lastError = new Error(`API Gemini (${model}): HTTP ${response.status}`);
        continue;
      }

      const data = await response.json();
      const candidateText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!candidateText) {
        lastError = new Error(`Modelo ${model} não retornou texto na resposta.`);
        continue;
      }

      // Safely parse JSON from candidate text
      let jsonStr = candidateText.trim();
      const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        jsonStr = jsonMatch[0];
      } else {
        jsonStr = jsonStr.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
      }
      const result = JSON.parse(jsonStr);
      result.modeloUtilizado = model;
      result.isLiveAi = true;
      result.horarioAnalise = new Date().toLocaleTimeString('pt-BR');
      console.log(`[IA Trader Vision ICT] Sucesso com ${model}: Sinal=${result.sinal}, Bias=${result.biasInstitucional}, Ativo=${result.ativo}`);
      return result;
    } catch (err) {
      console.error(`[IA Trader Vision ICT] Falha com modelo ${model}:`, err.message);
      lastError = err;
    }
  }

  // If all models failed
  throw lastError || new Error('Não foi possível analisar o gráfico com os modelos de IA disponíveis. Tente novamente em alguns segundos.');
}

// Check if APK exists
function findApkPath() {
  const possiblePaths = [
    path.join(__dirname, '.build-outputs', 'app-debug.apk'),
    path.join(__dirname, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk'),
    path.join(__dirname, '..', 'applet', '.build-outputs', 'app-debug.apk')
  ];
  for (const p of possiblePaths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// HTML UI Template
function getHtmlPage() {
  const sampleAlta = createSampleChartSvg('alta');
  const sampleBaixa = createSampleChartSvg('baixa');
  const sampleNeutro = createSampleChartSvg('neutro');
  const hasApk = Boolean(findApkPath());

  return `<!DOCTYPE html>
<html lang="pt-BR" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SxC IA - Análise Institucional de Mercado Financeiro</title>
  <meta name="description" content="SxC IA de Visão Computacional para análise institucional de gráficos com conceitos ICT: CISD de reversão e continuação, FVG, Liquidez e Teoria Trimestral.">
  <meta property="og:title" content="SxC IA - Análise de Mercado">
  <meta property="og:description" content="Sinais precisos de COMPRA, VENDA ou NEUTRO com Inteligência Artificial a partir de screenshots com metodologia ICT e CISD.">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            brand: {
              50: '#ecfdf5',
              500: '#10b981',
              600: '#059669',
              700: '#047857'
            }
          }
        }
      }
    }
  </script>
  <style>
    @keyframes pulseGlow {
      0%, 100% { opacity: 0.9; transform: scale(1); }
      50% { opacity: 1; transform: scale(1.02); }
    }
    .pulse-signal {
      animation: pulseGlow 2.5s infinite ease-in-out;
    }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col font-sans selection:bg-emerald-500 selection:text-black">

  <!-- Top Bar -->
  <header class="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40">
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
      <div class="flex items-center space-x-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 flex items-center justify-center text-slate-950 font-black text-sm tracking-wider shadow-lg shadow-cyan-500/20">
          SxC
        </div>
        <div>
          <h1 class="font-bold text-lg text-white leading-tight flex items-center gap-2">
            SxC IA <span class="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-mono font-semibold">SMART MONEY CONCEPTS</span>
          </h1>
          <p class="text-xs text-slate-400">Entrega Algorítmica (IPDA) • CISD (Reversão & Continuação) • FVG • Liquidez • Quarterly Theory • SMT</p>
        </div>
      </div>

      <div class="flex items-center space-x-3">
        <div class="hidden sm:flex items-center space-x-2 text-xs text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-3 py-1.5 rounded-lg font-mono">
          <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span>Motor Institucional Online</span>
        </div>
        ${hasApk ? `
        <a href="/download/app-debug.apk" download="sxc-ia.apk" class="text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
          <svg class="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
          Baixar APK Android
        </a>` : ''}
      </div>
    </div>
  </header>

  <!-- Main Content Area -->
  <main class="flex-1 max-w-6xl w-full mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
    
    <!-- Left Column: Upload & Input -->
    <div class="lg:col-span-5 space-y-6">
      
      <!-- Upload Card -->
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
        <div>
          <h2 class="text-lg font-bold text-slate-100 flex items-center gap-2">
            <svg class="w-5 h-5 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
            Screenshot do Gráfico
          </h2>
          <p class="text-sm text-slate-400 mt-1">
            Envie o print do seu gráfico para decodificação algorítmica de fluxo institucional.
          </p>
        </div>

        <!-- Dropzone -->
        <div id="dropzone" class="border-2 border-dashed border-slate-700 hover:border-cyan-500/70 rounded-xl p-6 text-center cursor-pointer transition bg-slate-950/40 relative group">
          <input type="file" id="fileInput" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10" />
          
          <div id="dropzonePrompt" class="space-y-3 pointer-events-none">
            <div class="w-12 h-12 rounded-full bg-slate-800 group-hover:bg-cyan-950/60 mx-auto flex items-center justify-center transition border border-slate-700 group-hover:border-cyan-500/50">
              <svg class="w-6 h-6 text-slate-400 group-hover:text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            </div>
            <div>
              <span class="text-sm font-semibold text-cyan-400">Clique para selecionar</span>
              <span class="text-sm text-slate-400"> ou arraste o print aqui</span>
            </div>
            <div class="inline-flex items-center gap-1.5 bg-slate-800/80 border border-slate-700 px-2.5 py-1 rounded-md text-[11px] text-slate-300">
              <kbd class="font-mono bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700 text-cyan-400">Ctrl+V</kbd>
              <span>Cole diretamente da área de transferência</span>
            </div>
            <p class="text-xs text-slate-500">TradingView, MT5, Profit, Binance, Exness</p>
          </div>

          <!-- Preview Container -->
          <div id="imagePreviewContainer" class="hidden relative">
            <img id="imagePreview" class="max-h-64 mx-auto rounded-lg border border-slate-700 object-contain shadow-md" alt="Prévia do Gráfico" />
            <button id="removeImageBtn" type="button" class="absolute top-2 right-2 bg-slate-900/90 text-slate-300 hover:text-white p-1.5 rounded-full border border-slate-700 hover:bg-rose-900/80 transition z-20" title="Remover imagem">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>
        </div>

        <!-- Quick Samples Section -->
        <div class="space-y-2">
          <label class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Setups ICT de Exemplo (1 Clique):</label>
          <div class="grid grid-cols-3 gap-2">
            <button type="button" onclick="loadSample('alta')" class="text-left px-2.5 py-2.5 rounded-xl border border-emerald-900/40 bg-emerald-950/20 hover:bg-emerald-950/50 hover:border-emerald-600/60 transition group">
              <span class="block text-xs font-bold text-emerald-400 group-hover:underline">🟢 CISD Rev + BISI</span>
              <span class="block text-[10px] text-slate-400 truncate">Sweep SSL • NQ 15m</span>
            </button>
            <button type="button" onclick="loadSample('baixa')" class="text-left px-2.5 py-2.5 rounded-xl border border-rose-900/40 bg-rose-950/20 hover:bg-rose-950/50 hover:border-rose-600/60 transition group">
              <span class="block text-xs font-bold text-rose-400 group-hover:underline">🔴 CISD Rev + SIBI</span>
              <span class="block text-[10px] text-slate-400 truncate">Sweep BSL • ES 5m</span>
            </button>
            <button type="button" onclick="loadSample('neutro')" class="text-left px-2.5 py-2.5 rounded-xl border border-amber-900/40 bg-amber-950/20 hover:bg-amber-950/50 hover:border-amber-600/60 transition group">
              <span class="block text-xs font-bold text-amber-400 group-hover:underline">⚪ Q1 Range</span>
              <span class="block text-[10px] text-slate-400 truncate">Acumulação • EUR</span>
            </button>
          </div>
        </div>

        <!-- Parameters & Options -->
        <div class="grid grid-cols-2 gap-3 pt-1">
          <div>
            <label class="block text-xs font-medium text-slate-300 mb-1">Grupo de Ativos Correlacionados</label>
            <select id="marketSelect" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500">
              <option value="Índices Futuros EUA (NQ, ES, YM)">Índices EUA (NQ, ES, YM)</option>
              <option value="Forex & Dólar (EUR/USD, GBP/USD, DXY)">Forex (EUR/USD, DXY)</option>
              <option value="Criptomoedas (BTC, ETH, SOL)">Cripto (BTC, ETH, SOL)</option>
              <option value="Mercado Brasileiro (WIN, WDO B3)">B3 (WIN / WDO)</option>
              <option value="Auto-detectar da imagem">Auto-detectar da imagem</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-medium text-slate-300 mb-1">Timeframe Alvo</label>
            <select id="timeframeSelect" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500">
              <option value="Detectar da imagem">Auto-detectar da imagem</option>
              <option value="1m - 5m (Scalp Execution)">1m - 5m (Scalp Execution)</option>
              <option value="15m - 1h (Day Trade)">15m - 1h (Day Trade)</option>
              <option value="4h - Diário (Macro Bias)">4h - Diário (Macro Bias)</option>
            </select>
          </div>
        </div>

        <!-- Action Button -->
        <button id="analyzeBtn" type="button" class="w-full py-3.5 px-4 rounded-xl font-bold text-slate-950 bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 transition shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed">
          <svg class="w-5 h-5 text-slate-950" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
          <span id="btnText">Analisar com Metodologia ICT</span>
        </button>

      </div>

      <!-- ICT Concepts Guidance Card -->
      <div class="bg-slate-900/60 border border-slate-800/90 rounded-2xl p-5 text-xs text-slate-400 space-y-3">
        <div class="flex items-center gap-2 text-cyan-400 font-bold uppercase tracking-wider text-[11px]">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
          Pilares Institucionais Avaliados (Conceitos ICT):
        </div>
        <ul class="space-y-2 text-[11px] leading-relaxed">
          <li class="flex items-start gap-2">
            <span class="text-cyan-400 font-bold font-mono">1. CISD:</span>
            <span><strong class="text-slate-200">CISD de Reversão e Continuação</strong> — Mudança ou continuidade no estado de entrega algorítmica com displacement agressivo rompendo o último candle de entrega.</span>
          </li>
          <li class="flex items-start gap-2">
            <span class="text-cyan-400 font-bold font-mono">2. FVG:</span>
            <span><strong class="text-slate-200">Fair Value Gaps</strong> — Ineficiências de 3 candles (BISI para compras, SIBI para vendas) e nível de 50% Consequent Encroachment (CE).</span>
          </li>
          <li class="flex items-start gap-2">
            <span class="text-cyan-400 font-bold font-mono">3. LIQUIDEZ:</span>
            <span><strong class="text-slate-200">Níveis Buy / Sell Side</strong> — Mapeamento de piscinas BSL (EQH) e SSL (EQL) com sweeps e captura de ordens de varejo.</span>
          </li>
          <li class="flex items-start gap-2">
            <span class="text-cyan-400 font-bold font-mono">4. QUARTERLY:</span>
            <span><strong class="text-slate-200">Cenário conforme Quarterly Theory</strong> — Leitura temporal do ciclo AMTD de 90min (Q1 Acumulação, Q2 Manipulação / Judas, Q3 Distribuição, Q4 Exaustão).</span>
          </li>
          <li class="flex items-start gap-2">
            <span class="text-cyan-400 font-bold font-mono">5. ASSET SYNC:</span>
            <span><strong class="text-slate-200">Sincronização de Ativos & SMT</strong> — Análise comparativa entre ativos correlacionados e detecção de Divergência SMT institucional.</span>
          </li>
        </ul>
      </div>

    </div>

    <!-- Right Column: Results Area -->
    <div class="lg:col-span-7">
      
      <!-- Initial State -->
      <div id="emptyState" class="h-full min-h-[440px] bg-slate-900/40 border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center text-center space-y-4">
        <div class="w-16 h-16 rounded-2xl bg-slate-800/80 flex items-center justify-center text-cyan-400/60 border border-slate-700">
          <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
        </div>
        <div class="max-w-sm">
          <h3 class="font-bold text-slate-200 text-base">Pronto para Análise Institucional</h3>
          <p class="text-xs text-slate-400 mt-1.5 leading-relaxed">Carregue um print ou selecione um dos exemplos acima para ver a decodificação completa de CISD, FVG, Liquidez e Teoria Trimestral.</p>
        </div>
      </div>

      <!-- Loading State -->
      <div id="loadingState" class="hidden h-full min-h-[440px] bg-slate-900 border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center text-center space-y-5">
        <div class="relative">
          <div class="w-16 h-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin"></div>
          <div class="absolute inset-0 flex items-center justify-center">
            <span class="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></span>
          </div>
        </div>
        <div>
          <h3 class="font-bold text-slate-100 text-base" id="loadingStep">Decodificando Imagem com Gemini Multimodal Vision...</h3>
          <p class="text-xs text-slate-400 mt-1.5">Mapeando CISD, ineficiências (FVG), captura de BSL/SSL e ciclos trimestrais...</p>
        </div>
      </div>

      <!-- Error State -->
      <div id="errorCard" class="hidden bg-slate-900 border border-rose-800/80 rounded-2xl p-6 text-center space-y-4 shadow-xl">
        <div class="w-12 h-12 rounded-full bg-rose-950/60 border border-rose-800 text-rose-400 flex items-center justify-center mx-auto">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        </div>
        <div>
          <h3 class="font-bold text-rose-300 text-base">Falha na Análise Institucional</h3>
          <p class="text-xs text-slate-400 mt-1.5 max-w-sm mx-auto" id="errorMessageText">Não foi possível processar a imagem com a IA.</p>
        </div>
        <button type="button" onclick="analyzeChart()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition">
          Tentar Novamente
        </button>
      </div>

      <!-- ICT Result Card -->
      <div id="resultCard" class="hidden bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
        
        <!-- Live AI Badge and Timestamp -->
        <div class="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-3">
          <div class="inline-flex items-center gap-1.5 text-cyan-400 font-medium">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span id="modelInfo">Gemini Vision Multimodal • ICT Engine</span>
          </div>
          <div class="flex items-center gap-1 text-slate-400 font-mono text-[11px]">
            <svg class="w-3.5 h-3.5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            <span id="timestampInfo">--:--:--</span>
          </div>
        </div>

        <!-- Signal Header Banner with Institutional Bias -->
        <div id="signalBanner" class="rounded-xl p-5 border flex items-center justify-between transition-all">
          <div class="space-y-1">
            <span class="text-xs uppercase tracking-widest font-bold opacity-80" id="signalSubtext">Sinal Institucional</span>
            <div class="flex items-center gap-3">
              <span class="text-3xl font-black tracking-tight" id="signalText">COMPRA</span>
              <span id="signalBadge" class="text-xs font-bold px-2.5 py-1 rounded-full border">Bullish Bias</span>
            </div>
          </div>
          <div class="text-right">
            <span class="text-xs text-slate-400 block">Convicção do Algoritmo</span>
            <span class="text-2xl font-bold font-mono text-white" id="confidenceValue">88%</span>
          </div>
        </div>

        <!-- Meta info pills (Ativo, Tempo, Bias) -->
        <div class="grid grid-cols-3 gap-2 text-center">
          <div class="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5">
            <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">Ativo</span>
            <span class="text-xs font-bold text-slate-200 truncate block mt-0.5" id="assetName">NQ / Nasdaq</span>
          </div>
          <div class="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5">
            <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">Timeframe</span>
            <span class="text-xs font-bold text-slate-200 truncate block mt-0.5" id="timeframeValue">15m</span>
          </div>
          <div class="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5">
            <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-mono">Bias Institucional</span>
            <span class="text-xs font-bold text-slate-200 truncate block mt-0.5" id="biasValue">Bullish (Alta)</span>
          </div>
        </div>

        <!-- Bento Grid: The 5 ICT Core Concepts -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          
          <!-- 1. Estrutura de Entrega (CISD de Reversão / Continuação) Card -->
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-cyan-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
                Estrutura de Entrega (CISD)
              </span>
              <span id="estruturaTypeBadge" class="text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-500/40 bg-cyan-500/10 text-cyan-300">CISD de Reversão</span>
            </div>
            <div class="flex items-center justify-between text-[11px] text-slate-400">
              <span>Nível Rompido: <strong class="text-slate-200" id="pivoRompidoVal">Pivô Estrutural Relevante</strong></span>
              <span id="estruturaStatusBadge" class="text-[10px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 px-1.5 py-0.5 rounded">Displacement</span>
            </div>
            <p id="estruturaDetailsText" class="text-slate-300 text-[11px] leading-relaxed">Mudança no estado de entrega algorítmica com displacement agressivo e fechamento além do nível de entrega prévio.</p>
          </div>

          <!-- 2. Fair Value Gaps (FVG) Card -->
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-emerald-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                Fair Value Gaps (FVG)
              </span>
              <span id="fvgTypeBadge" class="text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/40 bg-emerald-500/10 text-emerald-300">Bullish FVG (BISI)</span>
            </div>
            <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Faixa: <strong class="text-slate-200" id="fvgZoneVal">18.120 - 18.150</strong></span>
              <span>50% CE: <strong class="text-emerald-300" id="fvgCeVal">18.135</strong></span>
            </div>
            <div class="flex items-center justify-between text-[10.5px]">
              <span class="text-slate-400">Status: <span class="text-slate-200 font-medium" id="fvgStatusVal">Aberto para teste em Discount</span></span>
            </div>
            <p id="fvgDetailsText" class="text-slate-400 text-[10.5px] leading-relaxed">Ineficiência de 3 candles sem sobreposição de pavios aberta para entrega de preço.</p>
          </div>

          <!-- 3. Níveis de Liquidez (Buy / Sell Side) Card -->
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-sky-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-sky-400"></span>
                Níveis de Liquidez (Buy / Sell Side)
              </span>
              <span id="liquiditySweepBadge" class="text-[10px] font-bold px-2 py-0.5 rounded border border-sky-500/40 bg-sky-500/10 text-sky-300">Sweep SSL Executado</span>
            </div>
            <div class="space-y-1 text-[11px]">
              <div class="flex items-center justify-between text-slate-400 font-mono">
                <span>BSL: <strong class="text-slate-200" id="bslPoolVal">EQH em 18.350 (Alvo)</strong></span>
                <span>SSL: <strong class="text-rose-300" id="sslPoolVal">EQL em 18.080 (Varrido)</strong></span>
              </div>
              <div class="text-[10.5px] text-slate-300">
                Alvo Principal: <strong class="text-sky-300 font-mono" id="liquidityTargetVal">BSL (Buy-Side Liquidity)</strong>
              </div>
            </div>
            <ul id="liquidityPoolsList" class="text-[10px] text-slate-400 space-y-0.5 font-mono"></ul>
          </div>

          <!-- 4. Cenário conforme a Quarterly Theory (AMTD) Card -->
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-amber-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                Cenário - Quarterly Theory (AMTD)
              </span>
              <span id="quarterlyPhaseBadge" class="text-[10px] font-bold px-2 py-0.5 rounded border border-amber-500/40 bg-amber-500/10 text-amber-300">Q3 (Distribuição)</span>
            </div>
            <div class="text-[10.5px] text-amber-300 font-mono flex items-center justify-between">
              <span>Ciclo de Tempo: <span id="quarterlyCycleVal" class="text-slate-200 font-sans">Sessão NY AM / Ciclo de 90min</span></span>
            </div>
            <p id="quarterlyDescText" class="text-slate-300 text-[11px] leading-relaxed">Expansão institucional verdadeira em andamento após manipulação Judas em Q2.</p>
          </div>

          <!-- 5. Sincronização de Ativos & SMT Card -->
          <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 space-y-2 md:col-span-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-purple-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-purple-400"></span>
                Sincronização de Ativos (Asset Sync & SMT Divergence)
              </span>
              <span id="smtStatusBadge" class="text-[10px] font-bold px-2 py-0.5 rounded border border-purple-500/40 bg-purple-500/10 text-purple-300">Divergência SMT</span>
            </div>
            <div class="flex items-center justify-between text-[11px] text-slate-400">
              <span>Correlação: <strong class="text-slate-200" id="smtAssetVal">NQ vs ES</strong></span>
              <span>PD Array: <strong class="text-cyan-300 font-mono" id="pdArrayVal">Discount (&lt; 50%)</strong></span>
            </div>
            <p id="smtDetailsText" class="text-slate-300 text-[11px] leading-relaxed">Falha em renovar mínima em relação ao ativo correlacionado, validando acumulação institucional.</p>
          </div>

        </div>

        <!-- Operational Levels (Entrada em FVG, Stop Loss Institucional, TP1, TP2) -->
        <div class="bg-slate-950/90 border border-slate-800 rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 class="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <svg class="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
              Execução Operacional ICT
            </h4>
            <span class="text-xs font-mono font-semibold text-cyan-400" id="rrRatio">Risco/Retorno 1:3.2</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span class="text-[10px] text-slate-400 block font-mono">Entrada (FVG/OB)</span>
              <span class="font-mono font-bold text-slate-200 text-xs truncate block mt-0.5" id="entryVal">-</span>
            </div>
            <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span class="text-[10px] text-rose-400 block font-mono">Invalidação (SL)</span>
              <span class="font-mono font-bold text-rose-300 text-xs truncate block mt-0.5" id="stopLossVal">-</span>
            </div>
            <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span class="text-[10px] text-emerald-400 block font-mono">TP 1 (IRL Interno)</span>
              <span class="font-mono font-bold text-emerald-300 text-xs truncate block mt-0.5" id="tp1Val">-</span>
            </div>
            <div class="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
              <span class="text-[10px] text-emerald-400 block font-mono">TP 2 (ERL Externo)</span>
              <span class="font-mono font-bold text-emerald-300 text-xs truncate block mt-0.5" id="tp2Val">-</span>
            </div>
          </div>
        </div>

        <!-- Confluences Tags -->
        <div class="space-y-2">
          <h4 class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Confluências Institucionais:</h4>
          <div id="confluencesTags" class="flex flex-wrap gap-1.5"></div>
        </div>

        <!-- Detailed Institutional Rationale -->
        <div class="bg-slate-950/50 border border-slate-800 rounded-xl p-4 space-y-1.5">
          <h4 class="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">Justificativa Analítica ICT:</h4>
          <p class="text-xs text-slate-300 leading-relaxed font-sans" id="rationaleText"></p>
        </div>

        <!-- Risk Disclaimer -->
        <div class="text-[11px] text-slate-500 border-t border-slate-800/80 pt-3">
          <p id="disclaimerText">Aviso: Análise baseada em entrega algorítmica de preço e Smart Money Concepts exclusivamente para estudo educacional.</p>
        </div>

      </div>

    </div>

  </main>

  <!-- Samples Data in Memory -->
  <script>
    const SAMPLES = {
      alta: "${sampleAlta}",
      baixa: "${sampleBaixa}",
      neutro: "${sampleNeutro}"
    };

    let currentImageData = null;

    const fileInput = document.getElementById('fileInput');
    const dropzone = document.getElementById('dropzone');
    const dropzonePrompt = document.getElementById('dropzonePrompt');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const removeImageBtn = document.getElementById('removeImageBtn');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const btnText = document.getElementById('btnText');

    const emptyState = document.getElementById('emptyState');
    const loadingState = document.getElementById('loadingState');
    const resultCard = document.getElementById('resultCard');
    const errorCard = document.getElementById('errorCard');
    const errorMessageText = document.getElementById('errorMessageText');
    const modelInfo = document.getElementById('modelInfo');
    const timestampInfo = document.getElementById('timestampInfo');

    function setImage(base64Uri) {
      currentImageData = base64Uri;
      imagePreview.src = base64Uri;
      imagePreviewContainer.classList.remove('hidden');
      dropzonePrompt.classList.add('hidden');
      errorCard.classList.add('hidden');
    }

    function clearImage() {
      currentImageData = null;
      fileInput.value = '';
      imagePreview.src = '';
      imagePreviewContainer.classList.add('hidden');
      dropzonePrompt.classList.remove('hidden');
      errorCard.classList.add('hidden');
      resultCard.classList.add('hidden');
      emptyState.classList.remove('hidden');
    }

    removeImageBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      clearImage();
    });

    fileInput.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target.result);
        analyzeChart();
      };
      reader.readAsDataURL(file);
    });

    // Drag and drop support
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('border-cyan-500', 'bg-cyan-950/20');
    });

    dropzone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      dropzone.classList.remove('border-cyan-500', 'bg-cyan-950/20');
    });

    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('border-cyan-500', 'bg-cyan-950/20');
      const files = e.dataTransfer?.files;
      if (files && files[0] && files[0].type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setImage(event.target.result);
          analyzeChart();
        };
        reader.readAsDataURL(files[0]);
      }
    });

    // Direct clipboard paste (Ctrl+V / Cmd+V)
    window.addEventListener('paste', (e) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
              setImage(event.target.result);
              analyzeChart();
            };
            reader.readAsDataURL(file);
            e.preventDefault();
            break;
          }
        }
      }
    });

    window.loadSample = function(type) {
      setImage(SAMPLES[type]);
      const marketSelect = document.getElementById('marketSelect');
      if (type === 'alta') marketSelect.value = 'Índices Futuros EUA (NQ, ES, YM)';
      if (type === 'baixa') marketSelect.value = 'Índices Futuros EUA (NQ, ES, YM)';
      if (type === 'neutro') marketSelect.value = 'Forex & Dólar (EUR/USD, GBP/USD, DXY)';
      
      // Auto-trigger analysis for snappy user satisfaction
      analyzeChart();
    };

    analyzeBtn.addEventListener('click', analyzeChart);

    async function analyzeChart() {
      if (!currentImageData) {
        alert('Por favor, faça upload de uma imagem, cole com Ctrl+V ou escolha um gráfico de exemplo.');
        return;
      }

      // Show loading
      emptyState.classList.add('hidden');
      resultCard.classList.add('hidden');
      errorCard.classList.add('hidden');
      loadingState.classList.remove('hidden');
      analyzeBtn.disabled = true;
      btnText.textContent = 'Decodificando Visão com IA...';

      const market = document.getElementById('marketSelect').value;
      const timeframe = document.getElementById('timeframeSelect').value;

      try {
        let retries = 2;
        let response = null;
        let lastErr = null;

        while (retries >= 0) {
          try {
            response = await fetch('/api/analyze', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                imageBase64: currentImageData,
                assetType: market,
                timeframeHint: timeframe
              })
            });

            // If reverse proxy / gateway is still starting up (502/503/504), wait and retry
            if ((response.status === 502 || response.status === 503 || response.status === 504) && retries > 0) {
              retries--;
              btnText.textContent = 'Aguardando inicialização do servidor...';
              await new Promise(r => setTimeout(r, 1200));
              continue;
            }
            break;
          } catch (netErr) {
            lastErr = netErr;
            if (retries > 0) {
              retries--;
              btnText.textContent = 'Reconectando ao servidor...';
              await new Promise(r => setTimeout(r, 1200));
              continue;
            }
            throw new Error('Falha de conexão com o servidor. Verifique se o serviço está ativo e tente novamente.');
          }
        }

        if (!response) {
          throw lastErr || new Error('Servidor não retornou resposta.');
        }

        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
          const rawText = await response.text();
          if (response.status === 502 || response.status === 503 || response.status === 504) {
            throw new Error('Servidor em inicialização temporária (HTTP ' + response.status + '). Por favor, aguarde alguns segundos e tente novamente.');
          }
          throw new Error('Resposta inesperada do servidor (HTTP ' + response.status + ').');
        }

        const data = await response.json();

        if (!response.ok || data.error) {
          throw new Error(data.message || data.error || ('Erro HTTP ' + response.status));
        }

        renderResult(data);
      } catch (err) {
        console.error('Falha na análise:', err);
        errorMessageText.textContent = err.message || 'A IA não conseguiu interpretar o gráfico. Verifique a imagem ou tente novamente.';
        errorCard.classList.remove('hidden');
        resultCard.classList.add('hidden');
      } finally {
        loadingState.classList.add('hidden');
        analyzeBtn.disabled = false;
        btnText.textContent = 'Analisar com Metodologia ICT';
      }
    }

    function renderResult(data) {
      errorCard.classList.add('hidden');
      const signalBanner = document.getElementById('signalBanner');
      const signalText = document.getElementById('signalText');
      const signalBadge = document.getElementById('signalBadge');
      const confidenceValue = document.getElementById('confidenceValue');

      // Model info
      if (data.modeloUtilizado) {
        const friendlyModel = data.modeloUtilizado.replace('gemini-', 'Gemini ').replace('-preview', '');
        modelInfo.textContent = 'IA Ativa: ' + friendlyModel + ' (Visão Multimodal ICT)';
      } else {
        modelInfo.textContent = 'Gemini Multimodal Vision • ICT Core';
      }
      timestampInfo.textContent = data.horarioAnalise || new Date().toLocaleTimeString('pt-BR');

      const signal = (data.sinal || 'NEUTRO').toUpperCase();
      signalText.textContent = signal;
      confidenceValue.textContent = (data.confianca || 85) + '%';

      const bias = data.biasInstitucional || (signal === 'COMPRA' ? 'Bullish (Alta)' : signal === 'VENDA' ? 'Bearish (Baixa)' : 'Neutro');
      document.getElementById('biasValue').textContent = bias;

      if (signal === 'COMPRA') {
        signalBanner.className = 'rounded-xl p-5 border border-emerald-500/40 bg-gradient-to-r from-emerald-950/80 to-slate-900 flex items-center justify-between text-emerald-400 shadow-lg shadow-emerald-950/50';
        signalBadge.className = 'text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-500/50 bg-emerald-500/20 text-emerald-300';
        signalBadge.textContent = 'Bullish Setup';
      } else if (signal === 'VENDA') {
        signalBanner.className = 'rounded-xl p-5 border border-rose-500/40 bg-gradient-to-r from-rose-950/80 to-slate-900 flex items-center justify-between text-rose-400 shadow-lg shadow-rose-950/50';
        signalBadge.className = 'text-xs font-bold px-2.5 py-1 rounded-full border border-rose-500/50 bg-rose-500/20 text-rose-300';
        signalBadge.textContent = 'Bearish Setup';
      } else {
        signalBanner.className = 'rounded-xl p-5 border border-amber-500/40 bg-gradient-to-r from-amber-950/80 to-slate-900 flex items-center justify-between text-amber-400 shadow-lg shadow-amber-950/50';
        signalBadge.className = 'text-xs font-bold px-2.5 py-1 rounded-full border border-amber-500/50 bg-amber-500/20 text-amber-300';
        signalBadge.textContent = 'Aguardar / Neutro';
      }

      document.getElementById('assetName').textContent = data.ativo || 'Ativo Detectado';
      document.getElementById('timeframeValue').textContent = data.tempoGrafico || '15m';

      // 1. Estrutura de Entrega (CISD de Reversão / Continuação) Card
      const em = data.estruturaMercado || data.cisd || {};
      const estruturaTypeBadge = document.getElementById('estruturaTypeBadge');
      let emType = em.tipo || (em.status === 'Confirmado com Displacement' || em.status === 'Confirmado' ? 'CISD de Reversão' : 'Sem Quebra Estrutural');
      // Normalize legacy terms if any
      if (emType.includes('MSS')) emType = emType.replace('MSS (Market Structure Shift)', 'CISD de Reversão').replace('MSS', 'CISD de Reversão');
      if (emType.includes('BOS')) emType = emType.replace('BOS (Break of Structure)', 'CISD de Continuação').replace('BOS', 'CISD de Continuação');
      
      estruturaTypeBadge.textContent = emType;
      if (emType.toLowerCase().includes('cisd') || emType.toLowerCase().includes('revers') || emType.toLowerCase().includes('continua')) {
        estruturaTypeBadge.className = 'text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-500/40 bg-cyan-500/10 text-cyan-300';
      } else {
        estruturaTypeBadge.className = 'text-[10px] font-bold px-2 py-0.5 rounded border border-slate-700 bg-slate-800 text-slate-400';
      }
      document.getElementById('pivoRompidoVal').textContent = em.pivoOuNivelRompido || em.pivo || 'Nível Chave de Entrega';
      document.getElementById('estruturaStatusBadge').textContent = em.status || 'Confirmado';
      document.getElementById('estruturaDetailsText').textContent = em.detalhes || em.displacement || 'Mudança no estado de entrega algorítmica com displacement agressivo e fechamento além do pivô.';

      // 2. Fair Value Gaps (FVG) Card
      const fvg = data.fairValueGaps || data.fvg || {};
      const fvgTypeBadge = document.getElementById('fvgTypeBadge');
      const fvgTipo = fvg.tipo || 'Bullish FVG (BISI)';
      fvgTypeBadge.textContent = fvgTipo;
      if (fvgTipo.toLowerCase().includes('bullish') || fvgTipo.toLowerCase().includes('bisi')) {
        fvgTypeBadge.className = 'text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/40 bg-emerald-500/10 text-emerald-300';
      } else if (fvgTipo.toLowerCase().includes('bearish') || fvgTipo.toLowerCase().includes('sibi')) {
        fvgTypeBadge.className = 'text-[10px] font-bold px-2 py-0.5 rounded border border-rose-500/40 bg-rose-500/10 text-rose-300';
      } else {
        fvgTypeBadge.className = 'text-[10px] font-bold px-2 py-0.5 rounded border border-slate-700 bg-slate-800 text-slate-300';
      }
      document.getElementById('fvgZoneVal').textContent = fvg.faixaPreco || 'Identificada no gráfico';
      document.getElementById('fvgCeVal').textContent = fvg.consequentEncroachment || '50% Consequent Encroachment';
      document.getElementById('fvgStatusVal').textContent = fvg.statusMitigacao || 'Aberto para teste em Discount';
      document.getElementById('fvgDetailsText').textContent = fvg.detalhes || 'Ineficiência de 3 candles sem sobreposição de pavios aberta para entrega de preço.';

      // 3. Níveis de Liquidez (Buy / Sell Side) Card
      const liq = data.niveisLiquidez || data.liquidez || {};
      document.getElementById('bslPoolVal').textContent = liq.buySideLiquidity_BSL || liq.bsl || 'EQH / Máximas anteriores';
      document.getElementById('sslPoolVal').textContent = liq.sellSideLiquidity_SSL || liq.ssl || 'EQL / Mínimas anteriores';
      document.getElementById('liquidityTargetVal').textContent = liq.alvoPrincipal || 'BSL (Buy-Side Liquidity)';
      document.getElementById('liquiditySweepBadge').textContent = liq.sweepDetectado || 'Sweep Concluído';
      const poolsList = document.getElementById('liquidityPoolsList');
      poolsList.innerHTML = '';
      const pools = liq.piscinasMapeadas || ['EQH (Topos Iguais) • BSL', 'EQL (Fundos Iguais) • SSL'];
      pools.forEach(p => {
        const li = document.createElement('li');
        li.className = 'flex items-center gap-1.5';
        li.innerHTML = '<span class="text-sky-400 font-bold">•</span><span>' + p + '</span>';
        poolsList.appendChild(li);
      });

      // 4. Cenário conforme a Quarterly Theory (AMTD) Card
      const qt = data.quarterlyTheory || {};
      const qtBadge = document.getElementById('quarterlyPhaseBadge');
      qtBadge.textContent = qt.faseAtual || 'Q3 (Distribuição / Expansão)';
      document.getElementById('quarterlyCycleVal').textContent = qt.cicloTempo || 'Ciclo de 90min / Sessão Institucional';
      document.getElementById('quarterlyDescText').textContent = qt.descricaoCenario || qt.leituraCiclo || 'Cenário de expansão institucional verdadeiro após manipulação.';

      // 5. Sincronização de Ativos & SMT Card
      const smt = data.sincronizacaoAtivos || data.assetSyncSmt || {};
      document.getElementById('smtStatusBadge').textContent = smt.statusSMT || smt.statusSmt || 'Divergência SMT';
      document.getElementById('smtAssetVal').textContent = smt.ativosCorrelacionados || smt.correlacaoAtivos || 'NQ vs ES';
      const pd = data.pdArray || {};
      document.getElementById('pdArrayVal').textContent = (pd.zona || 'Discount (< 50%)') + (pd.orderBlock ? ' • ' + pd.orderBlock : '');
      document.getElementById('smtDetailsText').textContent = smt.descricaoSincronizacao || smt.analiseSincronizacao || 'Validação de simetria de topos/fundos entre ativos correlacionados.';

      // Operational Execution
      const pts = data.pontosOperacionais || {};
      document.getElementById('entryVal').textContent = pts.entrada || 'Reteste no FVG/OB';
      document.getElementById('stopLossVal').textContent = pts.stopLoss || 'Invalidação abaixo do sweep';
      document.getElementById('tp1Val').textContent = pts.takeProfit1 || 'IRL (Liquidez Interna)';
      document.getElementById('tp2Val').textContent = pts.takeProfit2 || 'ERL (Liquidez Externa)';
      document.getElementById('rrRatio').textContent = 'Risco/Retorno ' + (pts.riscoRetorno || '1 : 3');

      // Confluences Tags
      const tagsContainer = document.getElementById('confluencesTags');
      tagsContainer.innerHTML = '';
      const confluences = data.confluenciasIct || data.fatoresConfluencia || [
        'Sweep de Liquidez em sessão prévia',
        'CISD confirmado com forte displacement',
        'Reteste em Bullish FVG (BISI) em zona de Discount'
      ];
      confluences.forEach(c => {
        const span = document.createElement('span');
        span.className = 'bg-slate-800/90 text-cyan-300 border border-slate-700 text-[11px] px-2.5 py-1 rounded-md font-mono';
        span.textContent = c;
        tagsContainer.appendChild(span);
      });

      // Rationale & Disclaimer
      document.getElementById('rationaleText').textContent = data.justificativaIct || data.justificativaTecnica || 'Entrega algorítmica de preço em conformidade com Smart Money Concepts.';
      document.getElementById('disclaimerText').textContent = data.avisoRisco || 'Aviso: Análise baseada em entrega algorítmica de preço e metodologia ICT para fins educacionais.';

      resultCard.classList.remove('hidden');
    }
  </script>

</body>
</html>
`;
}

// Request Handler
const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Health check
  if (pathname === '/health' || pathname === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', app: 'SxC IA', uptime: process.uptime() }));
    return;
  }

  // Download APK endpoint
  if (pathname === '/download/app-debug.apk' || pathname === '/app-debug.apk') {
    const apkPath = findApkPath();
    if (apkPath && fs.existsSync(apkPath)) {
      const stat = fs.statSync(apkPath);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.android.package-archive',
        'Content-Length': stat.size,
        'Content-Disposition': 'attachment; filename="sxc-ia.apk"'
      });
      fs.createReadStream(apkPath).pipe(res);
      return;
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('APK not found or build in progress');
      return;
    }
  }

  // Vision Analysis API
  if (pathname === '/api/analyze' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 25 * 1024 * 1024) { // 25MB limit
        req.destroy();
      }
    });

    req.on('end', async () => {
      try {
        const payload = JSON.parse(body);
        if (!payload.imageBase64) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'imageBase64 é obrigatório' }));
          return;
        }

        const analysis = await analyzeChartWithGemini(
          payload.imageBase64,
          payload.mimeType || 'image/png',
          payload.assetType || '',
          payload.timeframeHint || ''
        );

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(analysis));
      } catch (err) {
        console.error('Error in /api/analyze:', err);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: true, message: err.message || 'Falha ao processar imagem com IA' }));
      }
    });
    return;
  }

  // Main UI
  if (pathname === '/' || pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(getHtmlPage());
    return;
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[SxC IA Dev Server] Servidor escutando na porta ${PORT} (0.0.0.0:${PORT})`);
});
