package com.example.data.sample

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.example.data.model.TradeAnalysisResult
import com.example.data.model.TradeSignal

data class Candle(
    val open: Float,
    val high: Float,
    val low: Float,
    val close: Float,
    val volume: Float
)

data class SampleMarketPreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val asset: String,
    val timeframe: String,
    val expectedSignal: TradeSignal,
    val description: String,
    val candles: List<Candle>,
    val supportLevel: Float,
    val resistanceLevel: Float,
    val fallbackAnalysis: TradeAnalysisResult
)

object ChartGenerator {

    fun generateBitmapForPreset(preset: SampleMarketPreset, width: Int = 1000, height: Int = 600): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply {
            color = Color.parseColor("#0F141C")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Margins
        val marginLeft = 30f
        val marginRight = 110f
        val marginTop = 80f
        val marginBottom = 100f
        val chartAreaWidth = width - marginLeft - marginRight
        val chartAreaHeight = height - marginTop - marginBottom

        // Min & Max prices
        val allHighs = preset.candles.map { it.high }
        val allLows = preset.candles.map { it.low }
        val rawMin = (allLows.minOrNull() ?: 100f) * 0.995f
        val rawMax = (allHighs.maxOrNull() ?: 200f) * 1.005f
        val priceRange = if (rawMax - rawMin == 0f) 1f else rawMax - rawMin

        fun priceToY(price: Float): Float {
            val normalized = (price - rawMin) / priceRange
            return (marginTop + chartAreaHeight) - (normalized * chartAreaHeight)
        }

        // Draw grid lines
        val gridPaint = Paint().apply {
            color = Color.parseColor("#1F2937")
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
        }
        val textPaint = Paint().apply {
            color = Color.parseColor("#9CA3AF")
            textSize = 20f
            isAntiAlias = true
        }

        val numGridLines = 6
        for (i in 0..numGridLines) {
            val y = marginTop + (chartAreaHeight / numGridLines) * i
            canvas.drawLine(marginLeft, y, width - marginRight, y, gridPaint)
            val priceVal = rawMax - (priceRange / numGridLines) * i
            val formattedPrice = if (priceVal >= 1000) String.format("%.0f", priceVal) else String.format("%.2f", priceVal)
            canvas.drawText(formattedPrice, width - marginRight + 10f, y + 6f, textPaint)
        }

        // Draw Support Line
        if (preset.supportLevel > 0f) {
            val supY = priceToY(preset.supportLevel)
            val supPaint = Paint().apply {
                color = Color.parseColor("#10B981")
                strokeWidth = 2f
                style = Paint.Style.STROKE
                pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
            }
            canvas.drawLine(marginLeft, supY, width - marginRight, supY, supPaint)
            val supTextPaint = Paint().apply {
                color = Color.parseColor("#10B981")
                textSize = 18f
                isAntiAlias = true
            }
            canvas.drawText("SUPORTE", marginLeft + 10f, supY - 8f, supTextPaint)
        }

        // Draw Resistance Line
        if (preset.resistanceLevel > 0f) {
            val resY = priceToY(preset.resistanceLevel)
            val resPaint = Paint().apply {
                color = Color.parseColor("#EF4444")
                strokeWidth = 2f
                style = Paint.Style.STROKE
                pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
            }
            canvas.drawLine(marginLeft, resY, width - marginRight, resY, resPaint)
            val resTextPaint = Paint().apply {
                color = Color.parseColor("#EF4444")
                textSize = 18f
                isAntiAlias = true
            }
            canvas.drawText("RESISTÊNCIA", marginLeft + 10f, resY - 8f, resTextPaint)
        }

        // Draw Candles
        val numCandles = preset.candles.size
        val candleSpacing = chartAreaWidth / numCandles
        val candleWidth = candleSpacing * 0.65f

        val greenPaint = Paint().apply {
            color = Color.parseColor("#10B981")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val redPaint = Paint().apply {
            color = Color.parseColor("#EF4444")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val wickPaint = Paint().apply {
            strokeWidth = 2.5f
            isAntiAlias = true
        }

        // EMA 20 points
        val emaPoints = mutableListOf<Pair<Float, Float>>()
        var currentEma = preset.candles.firstOrNull()?.close ?: 0f
        val alpha = 2f / (20f + 1f)

        preset.candles.forEachIndexed { index, candle ->
            val centerX = marginLeft + (index * candleSpacing) + (candleSpacing / 2f)
            val openY = priceToY(candle.open)
            val closeY = priceToY(candle.close)
            val highY = priceToY(candle.high)
            val lowY = priceToY(candle.low)

            val isBullish = candle.close >= candle.open
            val paint = if (isBullish) greenPaint else redPaint
            wickPaint.color = paint.color

            // Wick
            canvas.drawLine(centerX, highY, centerX, lowY, wickPaint)

            // Body
            val topY = kotlin.math.min(openY, closeY)
            val bottomY = kotlin.math.max(openY, closeY)
            val bodyRect = RectF(
                centerX - candleWidth / 2f,
                topY,
                centerX + candleWidth / 2f,
                if (bottomY - topY < 3f) topY + 3f else bottomY
            )
            canvas.drawRect(bodyRect, paint)

            // Volume bar at bottom
            val maxVol = (preset.candles.map { it.volume }.maxOrNull() ?: 100f) * 1.5f
            val volHeight = (candle.volume / maxVol) * (marginBottom * 0.65f)
            val volPaint = Paint().apply {
                color = if (isBullish) Color.parseColor("#3310B981") else Color.parseColor("#33EF4444")
                style = Paint.Style.FILL
            }
            val volRect = RectF(
                centerX - candleWidth / 2f,
                height - 20f - volHeight,
                centerX + candleWidth / 2f,
                height - 20f
            )
            canvas.drawRect(volRect, volPaint)

            // Calculate EMA
            currentEma = (candle.close * alpha) + (currentEma * (1f - alpha))
            emaPoints.add(Pair(centerX, priceToY(currentEma)))
        }

        // Draw EMA 20 line
        if (emaPoints.size > 1) {
            val emaPath = Path()
            emaPath.moveTo(emaPoints[0].first, emaPoints[0].second)
            for (i in 1 until emaPoints.size) {
                emaPath.lineTo(emaPoints[i].first, emaPoints[i].second)
            }
            val emaPaint = Paint().apply {
                color = Color.parseColor("#06B6D4")
                strokeWidth = 3f
                style = Paint.Style.STROKE
                isAntiAlias = true
            }
            canvas.drawPath(emaPath, emaPaint)
        }

        // Header watermark on chart
        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("${preset.asset} • ${preset.timeframe}", marginLeft, 45f, headerPaint)

        val subHeaderPaint = Paint().apply {
            color = Color.parseColor("#06B6D4")
            textSize = 18f
            isAntiAlias = true
        }
        canvas.drawText("EMA(20) • Volume", marginLeft + 320f, 45f, subHeaderPaint)

        return bitmap
    }

    val PRESETS = listOf(
        SampleMarketPreset(
            id = "btc_usdt_breakout",
            title = "NQ Futures - Setup CISD de Reversão + BISI",
            subtitle = "ICT • 15m • Sweep de Sell-Side Liquidity (SSL)",
            asset = "NQ (Nasdaq Futures)",
            timeframe = "15m",
            expectedSignal = TradeSignal.COMPRA,
            description = "Sweep de SSL na mínima da sessão anterior seguido de forte deslocamento (displacement), confirmando Bullish CISD de Reversão e gerando Bullish FVG (BISI).",
            supportLevel = 62200f,
            resistanceLevel = 65800f,
            candles = listOf(
                Candle(64200f, 64400f, 63800f, 64000f, 120f),
                Candle(64000f, 64100f, 63500f, 63600f, 150f),
                Candle(63600f, 63700f, 62900f, 63000f, 180f),
                Candle(63000f, 63200f, 62500f, 62600f, 210f),
                Candle(62600f, 62700f, 62200f, 62300f, 250f), // Testa SSL
                Candle(62300f, 63200f, 62150f, 63100f, 420f), // Sweep de SSL e ignição institucional
                Candle(63100f, 63800f, 63000f, 63700f, 380f), // Displacement (CISD de Reversão)
                Candle(63700f, 64500f, 63600f, 64400f, 450f), // FVG (BISI) gerado
                Candle(64400f, 65100f, 64300f, 64950f, 390f),
                Candle(64950f, 65400f, 64800f, 65300f, 360f)
            ),
            fallbackAnalysis = TradeAnalysisResult(
                signal = TradeSignal.COMPRA,
                confidencePercent = 90,
                trend = "Bullish (Order Flow de Alta Institucional)",
                asset = "NQ (Nasdaq Futures)",
                timeframe = "15m",
                identifiedPatterns = listOf(
                    "Bullish CISD de Reversão confirmado com displacement",
                    "Bullish FVG (BISI) em aberto para teste",
                    "Sweep de Sell-Side Liquidity (SSL)",
                    "Q3 Expansão Institucional (Quarterly Theory)"
                ),
                nearestSupport = "SSL Pool / Bullish OB em 62.150",
                nearestResistance = "BSL Pool / Buy-Side em 65.800",
                stopLossSuggestion = "62.050 (Abaixo da mínima do sweep de SSL)",
                takeProfitSuggestion = "65.600 (Piscina de liquidez externa ERL)",
                riskRewardRatio = "1 : 3.4",
                rationale = "O algoritmo IPDA realizou uma captura de Sell-Side Liquidity (SSL) abaixo da mínima prévia e produziu forte displacement comprador. O fechamento confirmou o CISD de Reversão (Change In State of Delivery) e abriu um Bullish FVG (BISI) em zona de Discount, validando a continuidade compradora para caça de BSL.",
                observedIndicators = listOf(
                    "Consequent Encroachment (50% do FVG em 63.400)",
                    "Dealing Range em Discount (< 50%)",
                    "SMT Divergence positiva frente ao ES",
                    "Algoritmo IPDA em entrega compradora"
                ),
                riskManagementRecommendation = "Entrada limite refinada no nível de 50% CE do FVG. Stop loss de invalidação institucional rigorosamente posicionado abaixo da mínima do sweep.",
                isLiveAi = false
            )
        ),
        SampleMarketPreset(
            id = "win_b3_sell",
            title = "ES Mini - CISD de Reversão Baixista + SIBI",
            subtitle = "ICT • 5m • Sweep de Buy-Side Liquidity (BSL)",
            asset = "ES (S&P 500 Futures)",
            timeframe = "5m",
            expectedSignal = TradeSignal.VENDA,
            description = "Falsa expansão de alta no início da sessão (Judas Swing em Q2), capturando Buy-Side Liquidity (BSL) em topo anterior e gerando Bearish CISD de Reversão com SIBI.",
            supportLevel = 130500f,
            resistanceLevel = 132800f,
            candles = listOf(
                Candle(131200f, 131800f, 131100f, 131700f, 90f),
                Candle(131700f, 132200f, 131600f, 132100f, 110f),
                Candle(132100f, 132600f, 132000f, 132550f, 130f),
                Candle(132550f, 132850f, 132400f, 132800f, 160f),
                Candle(132800f, 132900f, 132700f, 132750f, 85f),  // Sweep BSL
                Candle(132750f, 132800f, 131900f, 132000f, 290f), // Displacement vendedor / CISD de Reversão
                Candle(132000f, 132100f, 131500f, 131600f, 240f), // Bearish FVG (SIBI)
                Candle(131600f, 131750f, 131200f, 131300f, 210f)
            ),
            fallbackAnalysis = TradeAnalysisResult(
                signal = TradeSignal.VENDA,
                confidencePercent = 88,
                trend = "Bearish (Order Flow de Baixa Institucional)",
                asset = "ES (S&P 500 Futures)",
                timeframe = "5m",
                identifiedPatterns = listOf(
                    "Bearish CISD de Reversão com forte displacement",
                    "Bearish FVG (SIBI) aberto em Premium",
                    "Sweep de Buy-Side Liquidity (BSL / EQH)",
                    "Manipulação Judas Swing em Q2 concluída"
                ),
                nearestSupport = "SSL Pool / Sell-Side em 130.500",
                nearestResistance = "BSL Pool / Bearish OB em 132.850",
                stopLossSuggestion = "132.950 (Acima da máxima da manipulação de BSL)",
                takeProfitSuggestion = "130.700 (Piscina de SSL em liquidez externa ERL)",
                riskRewardRatio = "1 : 3.0",
                rationale = "Durante a fase Q2 (Quarterly Theory), o preço armou uma manipulação Judas Swing caçando o BSL em 132.850 pontos. Em seguida, o algoritmo IPDA reverteu agressivamente gerando um CISD de Reversão Baixista com displacement vendedor, quebrando o último candle de entrega e abrindo um Bearish FVG (SIBI) em Premium.",
                observedIndicators = listOf(
                    "Rejeição em Premium Array (> 50% do range)",
                    "Bearish Order Block mitigado",
                    "SMT Divergence (NQ renovou máxima enquanto ES falhou)",
                    "Entrega de preço acelerada em direção à SSL"
                ),
                riskManagementRecommendation = "Venda no teste do Bearish FVG (SIBI). Mantenha o stop acima da máxima do sweep para proteção institucional.",
                isLiveAi = false
            )
        ),
        SampleMarketPreset(
            id = "eur_usd_neutral",
            title = "EUR/USD - Q1 Asian Range (Consolidação)",
            subtitle = "ICT • 1h • Liquidez Intacta nos Dois Lados",
            asset = "EUR/USD",
            timeframe = "1h",
            expectedSignal = TradeSignal.NEUTRO,
            description = "Preço oscilando no equilíbrio do Range Asiático (Q1) sem realização de sweep de liquidez nem CISD de reversão ou continuação.",
            supportLevel = 1.0780f,
            resistanceLevel = 1.0890f,
            candles = listOf(
                Candle(1.0830f, 1.0870f, 1.0820f, 1.0850f, 50f),
                Candle(1.0850f, 1.0885f, 1.0840f, 1.0875f, 55f),
                Candle(1.0875f, 1.0890f, 1.0850f, 1.0860f, 60f),
                Candle(1.0860f, 1.0870f, 1.0810f, 1.0825f, 65f),
                Candle(1.0825f, 1.0845f, 1.0800f, 1.0810f, 70f),
                Candle(1.0810f, 1.0835f, 1.0790f, 1.0820f, 45f),
                Candle(1.0820f, 1.0850f, 1.0815f, 1.0840f, 40f),
                Candle(1.0840f, 1.0860f, 1.0830f, 1.0845f, 35f)
            ),
            fallbackAnalysis = TradeAnalysisResult(
                signal = TradeSignal.NEUTRO,
                confidencePercent = 82,
                trend = "Consolidação Q1 (Sem desbalanceamento institucional)",
                asset = "EUR/USD",
                timeframe = "1h",
                identifiedPatterns = listOf(
                    "Q1 Asian Range em acumulação",
                    "Preço no Equilibrium (50% do range)",
                    "Sem CISD de reversão ou de continuação",
                    "Liquidez interna (IRL) retida"
                ),
                nearestSupport = "SSL Asiático em 1.0780",
                nearestResistance = "BSL Asiático em 1.0890",
                stopLossSuggestion = "Aguardar manipulação Judas em Q2",
                takeProfitSuggestion = "Aguardar expansão direcional em Q3",
                riskRewardRatio = "Inadequada (Mercado no Equilibrium sem sweep)",
                rationale = "O par opera confinado no centro do range asiático em equilíbrio (50%). Não houve sweep de Buy-Side Liquidity nem de Sell-Side Liquidity, e inexiste CISD de reversão ou de continuação e FVG direcional. Entradas no meio do range configuram armadilha de liquidez de varejo.",
                observedIndicators = listOf(
                    "BSL e SSL intactos aguardando captura de liquidez",
                    "Ausência de displacement institucional",
                    "Quarterly Theory: Fase Q1 de Acumulação",
                    "Preço operando na média do Fair Value"
                ),
                riskManagementRecommendation = "Disciplina operacional estrita: NÃO operar no meio do range. Aguarde a manipulação da sessão seguinte (Q2) realizar sweep de uma das extremidades.",
                isLiveAi = false
            )
        )
    )
}
