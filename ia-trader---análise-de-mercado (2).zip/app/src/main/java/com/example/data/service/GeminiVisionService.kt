package com.example.data.service

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.TradeAnalysisResult
import com.example.data.model.TradeSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiVisionService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun analyzeChartScreenshot(
        bitmap: Bitmap,
        customApiKey: String? = null
    ): Result<TradeAnalysisResult> = withContext(Dispatchers.IO) {
        try {
            val key = customApiKey?.trim().takeIf { !it.isNullOrBlank() }
                ?: BuildConfig.GEMINI_API_KEY.takeIf { it.isNotBlank() && it != "MY_GEMINI_API_KEY" }

            if (key.isNullOrBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("Chave de API do Gemini não configurada no ambiente. Configure no painel de segredos.")
                )
            }

            // Compress bitmap to base64 JPEG
            val outputStream = ByteArrayOutputStream()
            // Resize if too large to conserve bandwidth & latency
            val scaledBitmap = if (bitmap.width > 1280 || bitmap.height > 1280) {
                val ratio = 1280f / maxOf(bitmap.width, bitmap.height)
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * ratio).toInt(),
                    (bitmap.height * ratio).toInt(),
                    true
                )
            } else {
                bitmap
            }

            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val prompt = """
                Você é um especialista de elite em ICT (Inner Circle Trader) e Smart Money Concepts (SMC).
                Analise minuciosamente a imagem deste screenshot de gráfico financeiro sob a ótica de entrega algorítmica de preço (IPDA).
                
                NÃO use ou mencione indicadores técnicos de varejo convencionais (como RSI, IFR, MACD, Estocástico, Médias Móveis simples).
                Sua análise deve se basear ESTRITAMENTE nos 5 pilares institucionais do ICT:
                
                1. CISD (Change In State of Delivery - Reversão ou Continuação): Identifique se houve CISD de reversão (deslocamento agressivo com displacement após sweep de liquidez BSL/SSL fechando contra o estado de entrega anterior) ou CISD de continuação (displacement agressivo a favor do order flow vigente confirmando a continuidade da entrega algorítmica).
                2. FVG (Fair Value Gap): Mapeie ineficiências de liquidez (BISI para alta, SIBI para baixa) e o nível de 50% (Consequent Encroachment - CE).
                3. Níveis de Liquidez (Liquidity Pools & Sweeps): Identifique caça a stops de varejo em topos (Buy-Side Liquidity - BSL / EQH) ou fundos (Sell-Side Liquidity - SSL / EQL).
                4. Quarterly Theory (AMTD): Mapeie o ciclo de 90 minutos (Q1 Acumulação, Q2 Manipulação/Judas Swing, Q3 Distribuição/Expansão institucional, Q4 Reversão/Exaustão).
                5. Asset Synchronization & SMT: Avalie se o ativo está sincronizado com sua cesta correlacionada ou gerando divergência institucional SMT (ex: NQ vs ES, EUR vs DXY, WIN vs WDO).
                
                Critérios para o Sinal Institucional:
                - "COMPRA": Sweep de Sell-Side Liquidity (SSL) concluído + CISD de reversão ou de continuação de alta com displacement + criação de Bullish FVG (BISI) em zona de Discount (< 50% do range).
                - "VENDA": Sweep de Buy-Side Liquidity (BSL) concluído + CISD de reversão ou de continuação de baixa com displacement + criação de Bearish FVG (SIBI) em zona de Premium (> 50% do range).
                - "NEUTRO": Preço em consolidação (Q1 range asiático sem sweep), operando no Equilibrium (50%) sem desequilíbrio claro de liquidez nem CISD.

                Retorne ESTRITAMENTE um objeto JSON válido (sem caracteres de formatação markdown antes ou depois) com o seguinte esquema:
                {
                  "sinal": "COMPRA" | "VENDA" | "NEUTRO",
                  "confianca_percentual": 88,
                  "tendencia": "Bullish (Order Flow de Alta)" | "Bearish (Order Flow de Baixa)" | "Consolidação / Range",
                  "ativo_estimado": "Nome do ativo ou 'Não identificado'",
                  "tempo_grafico": "ex: 5m, 15m, 1h ou 'Não identificado'",
                  "padroes_identificados": [
                    "ex: Bullish CISD de reversão confirmado com displacement",
                    "ex: CISD de continuação institucional",
                    "ex: Bullish FVG (BISI) em aberto",
                    "ex: Sweep de SSL (Sell-Side Liquidity)",
                    "ex: Q3 Expansão Institucional (Quarterly Theory)"
                  ],
                  "suporte_mais_proximo": "ex: SSL Pool / Bullish OB em 18.100",
                  "resistencia_mais_proxima": "ex: BSL Pool / Bearish OB em 18.350",
                  "sugestao_stop_loss": "ex: Abaixo da mínima do sweep / invalidação do CISD",
                  "sugestao_take_profit": "ex: Alvo principal na piscina de BSL / ERL",
                  "relacao_risco_retorno": "ex: 1:3.2",
                  "justificativa": "Análise aprofundada baseada exclusivamente em ICT explicando o CISD (reversão ou continuação), o FVG gerado, a captura de liquidez BSL/SSL, a fase da Quarterly Theory e a sincronização institucional do fluxo.",
                  "indicadores_observados": [
                    "ex: Consequent Encroachment (50% do FVG)",
                    "ex: Dealing Range em Discount (< 50%)",
                    "ex: Manipulação Judas Swing em Q2",
                    "ex: Algoritmo IPDA ativo"
                  ],
                  "recomendacao_gestao_risco": "ex: Entrada refinada no reteste do FVG/50% CE. Invalidação imediata com fechamento fora da estrutura de entrega."
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                })
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())

            val modelsToTry = listOf("gemini-3.6-flash", "gemini-3.8-flash", "gemini-3.1-flash-lite")
            var lastErrorMessage = ""
            var responseBody = ""
            var isSuccess = false

            for (model in modelsToTry) {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                try {
                    val response = client.newCall(request).execute()
                    val bodyString = response.body?.string() ?: ""
                    if (response.isSuccessful) {
                        responseBody = bodyString
                        isSuccess = true
                        break
                    } else {
                        lastErrorMessage = "Model $model returned HTTP ${response.code}: $bodyString"
                    }
                } catch (e: Exception) {
                    lastErrorMessage = "Model $model exception: ${e.message}"
                }
            }

            if (!isSuccess) {
                return@withContext Result.failure(
                    Exception("Falha ao consultar IA multimodal: $lastErrorMessage")
                )
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("Nenhuma resposta retornada pela IA."))
            }

            val content = candidates.getJSONObject(0).getJSONObject("content")
            val parts = content.getJSONArray("parts")
            val rawText = parts.getJSONObject(0).getString("text")

            // Clean json if wrapped in ```json ... ```
            val cleanedJson = rawText
                .replace("```json", "")
                .replace("```", "")
                .trim()

            val parsed = JSONObject(cleanedJson)

            val patternsList = mutableListOf<String>()
            val patternsJson = parsed.optJSONArray("padroes_identificados")
            if (patternsJson != null) {
                for (i in 0 until patternsJson.length()) {
                    patternsList.add(patternsJson.getString(i))
                }
            }

            val indicatorsList = mutableListOf<String>()
            val indicatorsJson = parsed.optJSONArray("indicadores_observados")
            if (indicatorsJson != null) {
                for (i in 0 until indicatorsJson.length()) {
                    indicatorsList.add(indicatorsJson.getString(i))
                }
            }

            val signal = TradeSignal.fromString(parsed.optString("sinal", "NEUTRO"))
            val confidence = parsed.optInt("confianca_percentual", 75)

            val result = TradeAnalysisResult(
                signal = signal,
                confidencePercent = confidence.coerceIn(1, 100),
                trend = parsed.optString("tendencia", "Não identificada"),
                asset = parsed.optString("ativo_estimado", "Gráfico analisado"),
                timeframe = parsed.optString("tempo_grafico", "Automático"),
                identifiedPatterns = patternsList.ifEmpty { listOf("Análise de candles e fluxo") },
                nearestSupport = parsed.optString("suporte_mais_proximo", "Não especificado"),
                nearestResistance = parsed.optString("resistencia_mais_proxima", "Não especificado"),
                stopLossSuggestion = parsed.optString("sugestao_stop_loss", "Abaixo do suporte recente"),
                takeProfitSuggestion = parsed.optString("sugestao_take_profit", "Próxima resistência relevante"),
                riskRewardRatio = parsed.optString("relacao_risco_retorno", "1:2"),
                rationale = parsed.optString("justificativa", "Análise baseada em Price Action e estrutura de candles."),
                observedIndicators = indicatorsList.ifEmpty { listOf("Candlestick", "Níveis horizontais") },
                riskManagementRecommendation = parsed.optString("recomendacao_gestao_risco", "Nunca arrisque mais que 1% a 2% do seu capital total por operação."),
                isLiveAi = true,
                rawJson = cleanedJson
            )

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
