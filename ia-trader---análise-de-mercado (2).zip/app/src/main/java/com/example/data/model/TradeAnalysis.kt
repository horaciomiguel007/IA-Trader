package com.example.data.model

enum class TradeSignal(val label: String, val colorHex: Long) {
    COMPRA("COMPRA", 0xFF10B981),
    VENDA("VENDA", 0xFFEF4444),
    NEUTRO("NEUTRO", 0xFFF59E0B);

    companion object {
        fun fromString(value: String?): TradeSignal {
            return when (value?.uppercase()?.trim()) {
                "COMPRA", "BUY" -> COMPRA
                "VENDA", "SELL" -> VENDA
                else -> NEUTRO
            }
        }
    }
}

data class TradeAnalysisResult(
    val signal: TradeSignal,
    val confidencePercent: Int,
    val trend: String,
    val asset: String,
    val timeframe: String,
    val identifiedPatterns: List<String>,
    val nearestSupport: String,
    val nearestResistance: String,
    val stopLossSuggestion: String,
    val takeProfitSuggestion: String,
    val riskRewardRatio: String,
    val rationale: String,
    val observedIndicators: List<String>,
    val riskManagementRecommendation: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isLiveAi: Boolean = true,
    val rawJson: String? = null
)
