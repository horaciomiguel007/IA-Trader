package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TradeAnalysisResult
import com.example.data.model.TradeSignal
import com.example.data.sample.SampleMarketPreset
import com.example.ui.theme.BuyGreen
import com.example.ui.theme.BuyGreenBg
import com.example.ui.theme.BuyGreenLight
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanAccentLight
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.NeutralAmberBg
import com.example.ui.theme.NeutralAmberLight
import com.example.ui.theme.SellRed
import com.example.ui.theme.SellRedBg
import com.example.ui.theme.SellRedLight
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate850
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

@Composable
fun SignalBannerCard(
    result: TradeAnalysisResult,
    modifier: Modifier = Modifier
) {
    val (primaryColor, lightColor, bgColor, icon, label) = when (result.signal) {
        TradeSignal.COMPRA -> Tuple5(
            BuyGreen,
            BuyGreenLight,
            BuyGreenBg,
            Icons.Default.ArrowUpward,
            "SINAL: COMPRA"
        )
        TradeSignal.VENDA -> Tuple5(
            SellRed,
            SellRedLight,
            SellRedBg,
            Icons.Default.ArrowDownward,
            "SINAL: VENDA"
        )
        TradeSignal.NEUTRO -> Tuple5(
            NeutralAmber,
            NeutralAmberLight,
            NeutralAmberBg,
            Icons.Default.Remove,
            "SINAL: NEUTRO"
        )
    }

    val animatedConfidence by animateFloatAsState(
        targetValue = result.confidencePercent / 100f,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "confidence"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(2.dp, primaryColor.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        color = Slate900,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header: Live AI Badge & Timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(
                            if (result.isLiveAi) CyanAccent.copy(alpha = 0.15f) else Slate800,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (result.isLiveAi) Icons.Default.AutoAwesome else Icons.Default.Info,
                        contentDescription = null,
                        tint = if (result.isLiveAi) CyanAccentLight else Slate400,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (result.isLiveAi) "GEMINI 2.5 FLASH" else "SETUP TÉCNICO",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (result.isLiveAi) CyanAccentLight else Slate400,
                        letterSpacing = 0.5.sp
                    )
                }

                Text(
                    text = "${result.asset} • ${result.timeframe}",
                    fontSize = 12.sp,
                    color = Slate400,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Big Signal Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(bgColor.copy(alpha = 0.5f), CircleShape)
                            .border(2.dp, primaryColor, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = primaryColor,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = label,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = primaryColor,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Tendência: ${result.trend}",
                            fontSize = 14.sp,
                            color = Slate200,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Confidence Circle / Percentage
                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "${result.confidencePercent}%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = lightColor,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Confiança",
                        fontSize = 11.sp,
                        color = Slate400
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Confidence progress bar
            Column(modifier = Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = { animatedConfidence },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = primaryColor,
                    trackColor = Slate800,
                )
            }
        }
    }
}

private data class Tuple5<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)

@Composable
fun TradeSetupCard(
    result: TradeAnalysisResult,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Slate800, RoundedCornerShape(16.dp)),
        color = Slate900,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Timeline,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PARÂMETROS DE EXECUÇÃO",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccentLight,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Support & Resistance Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SetupParamBox(
                    label = "Suporte Chave",
                    value = result.nearestSupport,
                    accentColor = BuyGreen,
                    modifier = Modifier.weight(1f)
                )
                SetupParamBox(
                    label = "Resistência Chave",
                    value = result.nearestResistance,
                    accentColor = SellRed,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stop Loss & Take Profit Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SetupParamBox(
                    label = "Sugestão Stop Loss",
                    value = result.stopLossSuggestion,
                    accentColor = SellRedLight,
                    modifier = Modifier.weight(1f)
                )
                SetupParamBox(
                    label = "Sugestão Take Profit",
                    value = result.takeProfitSuggestion,
                    accentColor = BuyGreenLight,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Risk:Reward Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate850, RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = Slate400,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Relação Risco : Retorno",
                        fontSize = 13.sp,
                        color = Slate400
                    )
                }

                Text(
                    text = result.riskRewardRatio,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccentLight,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun SetupParamBox(
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Slate850, RoundedCornerShape(10.dp))
            .border(1.dp, Slate800, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 11.sp,
                color = Slate400,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = accentColor,
                lineHeight = 17.sp
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TechnicalPatternsCard(
    result: TradeAnalysisResult,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Slate800, RoundedCornerShape(16.dp)),
        color = Slate900,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ShowChart,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CONCEITOS INSTITUCIONAIS IDENTIFICADOS (ICT)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccentLight,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Candlestick Pattern Chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                result.identifiedPatterns.forEach { pattern ->
                    PatternChip(text = pattern, isPattern = true)
                }

                result.observedIndicators.forEach { indicator ->
                    PatternChip(text = indicator, isPattern = false)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Detailed Rationale
            Text(
                text = "JUSTIFICATIVA INSTITUCIONAL (SMART MONEY CONCEPTS):",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Slate400,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = result.rationale,
                fontSize = 14.sp,
                color = Slate200,
                lineHeight = 21.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Risk Management Tip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate850, RoundedCornerShape(10.dp))
                    .border(1.dp, Slate800, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = NeutralAmberLight,
                    modifier = Modifier
                        .size(18.dp)
                        .padding(top = 1.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Gestão de Risco Recomendada:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeutralAmberLight
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = result.riskManagementRecommendation,
                        fontSize = 12.sp,
                        color = Slate400,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PatternChip(
    text: String,
    isPattern: Boolean
) {
    val borderColor = if (isPattern) CyanAccent.copy(alpha = 0.4f) else Slate700
    val textColor = if (isPattern) CyanAccentLight else Slate200
    val bgColor = if (isPattern) CyanAccent.copy(alpha = 0.1f) else Slate850

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = if (isPattern) Icons.Default.CheckCircle else Icons.Default.Timeline,
            contentDescription = null,
            tint = textColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = textColor,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun PresetChartChips(
    presets: List<SampleMarketPreset>,
    selectedPresetId: String?,
    onPresetSelected: (SampleMarketPreset) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "OU ESCOLHA UM GRÁFICO DE TESTE:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Slate400,
            letterSpacing = 0.5.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { preset ->
                val isSelected = preset.id == selectedPresetId
                val signalColor = when (preset.expectedSignal) {
                    TradeSignal.COMPRA -> BuyGreen
                    TradeSignal.VENDA -> SellRed
                    TradeSignal.NEUTRO -> NeutralAmber
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onPresetSelected(preset) }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) signalColor else Slate800,
                            shape = RoundedCornerShape(12.dp)
                        ),
                    color = if (isSelected) Slate850 else Slate900,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = preset.asset,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(signalColor, CircleShape)
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "${preset.timeframe} • ${preset.expectedSignal.label}",
                            fontSize = 10.sp,
                            color = signalColor,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChartPreviewCard(
    bitmap: Bitmap?,
    isLoading: Boolean,
    loadingMessage: String,
    onUploadClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Slate800, RoundedCornerShape(16.dp)),
        color = Slate900,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Chart Frame
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Slate950)
                    .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Screenshot do Gráfico",
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ShowChart,
                            contentDescription = null,
                            tint = Slate600,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Nenhum screenshot carregado",
                            fontSize = 14.sp,
                            color = Slate400
                        )
                    }
                }

                // Loading overlay
                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(Slate950.copy(alpha = 0.88f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            CircularProgressIndicator(
                                color = CyanAccent,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = loadingMessage.ifBlank { "Analisando gráfico..." },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Slate200,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onUploadClick,
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Slate800,
                        contentColor = Slate200
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Upload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Enviar Print",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Button(
                    onClick = onAnalyzeClick,
                    enabled = !isLoading && bitmap != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent,
                        contentColor = Slate950
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Executar Análise",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun FinancialDisclaimerCard(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Slate900, RoundedCornerShape(12.dp))
            .border(1.dp, Slate800, RoundedCornerShape(12.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = NeutralAmber,
            modifier = Modifier
                .size(18.dp)
                .padding(top = 1.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = "Aviso de Risco & Isenção de Responsabilidade",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = NeutralAmberLight
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "Esta ferramenta utiliza inteligência artificial multimodal (Gemini Vision) para estudo técnico de Price Action e padrões gráficos. Os sinais emitidos não constituem recomendação formal de investimento. Mercados futuros, criptoativos e ações envolvem alto risco de perda patrimonial. Sempre utilize Stop Loss e gerencie sua alavancagem com prudência.",
                fontSize = 11.sp,
                color = Slate400,
                lineHeight = 16.sp
            )
        }
    }
}
