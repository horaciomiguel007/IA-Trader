package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate950 = Color(0xFF090D14)
val Slate900 = Color(0xFF0F1420)
val Slate850 = Color(0xFF161E2E)
val Slate800 = Color(0xFF1E283D)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)

// Trading Signal Colors
val BuyGreen = Color(0xFF10B981)
val BuyGreenLight = Color(0xFF34D399)
val BuyGreenBg = Color(0xFF064E3B)

val SellRed = Color(0xFFEF4444)
val SellRedLight = Color(0xFFF87171)
val SellRedBg = Color(0xFF7F1D1D)

val NeutralAmber = Color(0xFFF59E0B)
val NeutralAmberLight = Color(0xFFFBBF24)
val NeutralAmberBg = Color(0xFF78350F)

val CyanAccent = Color(0xFF06B6D4)
val CyanAccentLight = Color(0xFF67E8F9)
val PurpleAccent = Color(0xFF8B5CF6)
